# Vakit+ Codemagic Başlangıç

Bu paket Codemagic için hazırlanmıştır.

1. GitHub'a bu projenin içeriğini yükleyin.
2. Codemagic'te Android seçin.
3. Yapılandırma dosyası olarak proje kökündeki `codemagic.yaml` kullanılmalıdır.
4. İlk derlemede imzasız release APK üretilebilir.
5. Google Play için daha sonra keystore/signing bilgileri eklenmelidir.

Not: APK'nın gerçek üretimi Codemagic sunucusunda yapılır.
