# Vakit+ — TEK PAKET FINAL

Bu paket Vakit+ projesinin tek ZIP altında birleştirilmiş final kaynak paketidir.

## İçerik
- Android uygulaması: `VakitPlus/`
- Merkezi Owner backend: `VakitPlus/backend/`
- Yönetici paneli ve bildirim yönetimi
- Kullanıcı/cihaz yönetimi
- Güvenlik/Play Integrity/App Check hazırlığı
- Owner Dashboard
- Google Play yayın dokümanları
- Gizlilik politikası ve Data Safety hazırlığı
- Build alternatifleri
- Sürüm değişiklik kayıtları

## AAB oluşturma
1. ZIP'i çıkarın.
2. `VakitPlus` klasörünü bir Android geliştirme ortamında açın.
3. Android SDK 36 ve gerekli Gradle/AGP bileşenlerini kurun.
4. Firebase bağlantısı için kendi `google-services.json` dosyanızı `VakitPlus/app/` içine ekleyin.
5. Kendi release keystore'unuzu oluşturun ve güvenli saklayın.
6. `bundleRelease` ile imzalı AAB oluşturun.

## Önemli güvenlik
- Gerçek Owner parolası ZIP'e veya APK'ya yazılmamalıdır.
- Keystore, Firebase servis hesabı anahtarı ve token sırları paylaşılmamalıdır.
- Production backend HTTPS arkasında çalıştırılmalıdır.
- Play Integrity/App Check production Firebase/Play Console hesabınızda etkinleştirilmelidir.

## Mevcut ortam notu
Bu paket kaynak kodudur. Bu çalışma ortamında Android SDK/Gradle derleme zinciri olmadığı için imzalı APK/AAB dosyası pakete eklenmemiştir.


## Güncel derleme yolu
Firebase Studio yeni kayıt kabul etmediği için `VakitPlus/BUILD_ON_GITHUB_ACTIONS_TR.md` dosyasındaki GitHub Actions yöntemini kullanın.
